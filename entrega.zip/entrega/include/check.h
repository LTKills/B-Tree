#ifndef _CHECK_H_
#define _CHECK_H_

#include <stdlib.h>
#include <stdio.h>

#include <stdbool.h>
#include <ctype.h> 	// isdigit
#include <string.h>	// strlen

#include <utils.h>



bool checkInputDocument(char *doc);
bool checkInputDateAndTime(char *date);



#endif
