#ifndef _REMOTION_H_
#define _REMOTION_H_

#include <stdbool.h>

bool remove_record(t_files *files, t_list *list);

#endif
