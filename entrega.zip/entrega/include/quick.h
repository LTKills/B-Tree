/*
 * =====================================================================================
 *
 *       Filename:  quick.h
 *
 *    Description:  Quick sort implementation
 *
 *        Version:  1.0
 *        Created:  01-07-2017 14:38:56
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  LTKills
 *   Organization:  USP
 *
 * =====================================================================================
 */




void quickSort(int **vec, int start, int end);

