#ifndef _INSERTION_H_
#define _INSERTION_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <utils.h>


t_record *print_insert_menu();
void insert(t_files *files, t_list *lists);

#endif
