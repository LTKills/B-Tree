#ifndef _STATISTICS_H_
#define _STATISTICS_H_


void index_stats(t_files *files, t_list *lists);

void removed_stats(t_files *files, t_list *lists);

#endif
